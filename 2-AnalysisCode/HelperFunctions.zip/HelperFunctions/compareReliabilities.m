function itemRels_avg = compareReliabilities(SubjectModels, defineRuns, assessRuns)
% step 1: identify the reliable and active voxels using one half of the data
% step 2: calculate condition-pattern reliability within those voxels using
% the other half of the data
% step 3: plot and compare the condition-pattern reliabilities in reliable and
% active voxels


% inputs:
    % - SubjectModels: struct for each subject (mostly just with their
    % name)
    % - threshs: struct containing the thresholds used to define reliable
    % and active voxels
    % - data: struct containing betas for the whole brain for each sub,
    % stored separately for odd and even runs
    
    
    % - data: formatted data, specifically looking for this field:
    % brainPatterns.(methods{m}).(sub).allRuns
    % - methods: cell array of strings (1 per method, should match fields
    % in data.brainPatterns struct)
    % - colors: optional cell array of strings (1 per method) with colors
    % for each method
% -------------------------------------------------------------------------

keyboard

%% define reliable and active voxels
% in one half of the data

disp('defining active and reliable voxels in one half of the data...')
for s = 1:length(SubjectModels)
    % get subject
    S = SubjectModels(s);
    disp(S.name);
    
    % get split-half reliability in this half of the data:
    get1FoldSplitHalfVoxelReliability(S.brainPatterns, defineRuns)
    
end

% [voxelCorr] = getSplitHalfVoxelReliability18(S.brainPatterns);




%% calculate condition-pattern reliabilites
% for reliable and active voxels, in the *other* half of the data


% %% plot condition pattern reliabilities
% 
% % loop through the subjects, and get item reliabilities just for the
% % selected voxels:
% itemRels = zeros(length(methods), length(SubjectModels)); % average across items for each subject
% for s = 1:length(SubjectModels)
%     S = SubjectModels(s);
%     sub = S.name;
%             
%     % loop through the methods:
%     for m = 1:length(methods)
%         % pull out just the voxels selected by this method:
%         odd = data.brainPatterns.(methods{m}).(sub).oddRuns; % odd betas
%         even = data.brainPatterns.(methods{m}).(sub).evenRuns; % even betas
%         
%         % correlate for each item:
%         itemReliability = corrColumns(odd, even);
%         
%         % average across items for this subject / method:
%         itemRels(m, s) = mean(itemReliability);
%     end
% end
% 
% % collapse across subjects:
% itemRels_avg = mean(itemRels, 2);
% 
% % get sem error bars:
% itemRels_se = [];
% for s = 1:length(SubjectModels)
%    S = SubjectModels(s);
%    sub = S.name;
%    
%    % calculate standard error for each method:
%    for m = 1:length(methods)
%        itemRels_se(m) = (sqrt(sum((itemRels_avg(m) - itemRels(:, m)).^2)/(length(itemRels(:, m)) - 1))) / sqrt(length(itemRels(:, m)));
%    end
% end
% 
% % plot it
% 
% % On each box, the central mark indicates the median, and the bottom and 
% % top edges of the box indicate the 25th and 75th percentiles, 
% % respectively. The whiskers extend to the most extreme data points not 
% % considered outliers, and the outliers are plotted individually using the 
% % '+' symbol.
% 
% colorRef = {'yellow', 'y';...
%     'magenta', 'm';...
%     'cyan', 'c';...
%     'red', 'r';...
%     'green', 'g';...
%     'blue', 'b';...
%     'white', 'w';...
%     'black', 'k'};
% 
% figure('Color', [1 1 1])
% if exist('colors', 'var') % specified 1 color per method
%     % get the colors into a single string based on abbreviations
%     colorString = [];
%     for c = 1:length(colors)
%        cIdx = find(strcmp(lower(colors{c}), colorRef(:, 1)));
%        colorString = [colorString, colorRef{cIdx, 2}];
%     end
%     b = boxplot(itemRels', 'Colors', colorString); % doesn't seem to fill well...
% else
%     b = boxplot(itemRels'); 
% end
% 
% ylabel('average condition pattern reliability');
% ylim([0, 1])
% set(gca, 'Xticklabel', methods);
% 
% 
% 
% %% T-test
% 
% % Do methods have different condition pattern reliabilities?
% 
% [h, p, ci, stats] = ttest(itemRels(1, :), itemRels(2, :));
% 
% % print out the results to the command line:
% if p<0.05
%     star = '*';
% else
%     star = '(n.s.)';
% end
% statString = sprintf('t(%d)=%2.2f, p=%2.3f %s', ...
%     stats.df, stats.tstat, p, star);
% 
% if p < .05 && stats.tstat > 0
%     effectString = sprintf('\nHigher item pattern reliability using %s method than %s method.', methods{1}, methods{2});
% elseif p < .05 && stats.tstat < 0
%     effectString = sprintf('\nHigher item pattern reliability using %s method than %s method.', methods{2}, methods{1});
% else
%     effectString = '\nNo difference in number of voxels selected.';
% end
% 
% disp(effectString);
% disp(statString);

end