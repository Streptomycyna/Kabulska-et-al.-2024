function nVox_avg = compareVoxelCounts(SubjectModels, data, methods, colors)
% produces a plot to quickly compare voxel counts of included voxels
% between methods (with SEM error bars). 

% inputs:
    % - SubjectModels: struct for each subject (mostly just with their
    % name)
    % - data: formatted data, specifically looking for this field:
    % brainPatterns.(methods{m}).(sub).allRuns
    % - methods: cell array of strings (1 per method, should match fields
    % in data.brainPatterns struct)
    % - colors: optional cell array of strings (1 per method) with colors
    % for each method
% -------------------------------------------------------------------------
%% get average voxel count for each method

% loop through the subjects
nVox = zeros(length(SubjectModels), length(methods)); % subs x selection methods

for s = 1:length(SubjectModels)
    S = SubjectModels(s);
    sub = S.name;
    
    % pull out the voxel counts:
    for m = 1:length(methods)
       nVox(s, m) = size(data.brainPatterns.(methods{m}).(sub).allRuns, 1); 
    end
    
end

% collapse across subjects:
nVox_avg = mean(nVox);

%% get SEM error bars

nVox_se = [];
for s = 1:length(SubjectModels)
   S = SubjectModels(s);
   sub = S.name;
   
   % calculate standard error for each method:
   for m = 1:length(methods)
       nVox_se(m) = (sqrt(sum((nVox_avg(m) - nVox(:, m)).^2)/(length(nVox(:, m)) - 1))) / sqrt(length(nVox(:, m)));
   end
end

%% plot it

% old method: bar plot
% b = bar(nVox_avg);
% if exist('colors', 'var') % specified 1 color per method
%     hold on
%     for c = 1:length(colors)
%         b.FaceColor = colors{c};
%     end
%     hold off
% end

% % add in the error bars
% hold on
% eb = errorbar(nVox_avg, nVox_se, '.k');
% hold off

% new method: box plot

% On each box, the central mark indicates the median, and the bottom and 
% top edges of the box indicate the 25th and 75th percentiles, 
% respectively. The whiskers extend to the most extreme data points not 
% considered outliers, and the outliers are plotted individually using the 
% '+' symbol.

% set up colors lookup table
colorRef = {'yellow', 'y';...
    'magenta', 'm';...
    'cyan', 'c';...
    'red', 'r';...
    'green', 'g';...
    'blue', 'b';...
    'white', 'w';...
    'black', 'k'};

figure('Color', [1 1 1])
if exist('colors', 'var') % specified 1 color per method
    % get the colors into a single string based on abbreviations
    colorString = [];
    for c = 1:length(colors)
       cIdx = find(strcmp(lower(colors{c}), colorRef(:, 1)));
       colorString = [colorString, colorRef{cIdx, 2}];
    end
    b = boxplot(nVox, 'Colors', colorString); % doesn't seem to fill well...
else
    b = boxplot(nVox); 
end

ylabel('count of selected voxels');
set(gca, 'Xticklabel', methods);

%% t-test

% is there a difference in # of voxels selected by the 2 methods?
[h, p, ci, stats] = ttest(nVox(:, 1), nVox(:, 2));

% print out the results to the command line:
if p<0.05
    star = '*';
else
    star = '(n.s.)';
end
statString = sprintf('t(%d)=%2.2f, p=%2.3f %s', ...
    stats.df, stats.tstat, p, star);

if p < .05 && stats.tstat > 0
    effectString = sprintf('More voxels selected using %s method than %s method.', methods{1}, methods{2});
elseif p < .05 && stats.tstat < 0
    effectString = sprintf('More voxels selected using %s method than %s method.', methods{2}, methods{1});
else
    effectString = 'No difference in number of voxels selected.';
end

disp(effectString);
disp(statString);


end