function plotItemPatternHistAtThresh(R, r, saveDir)

saveFigFlag=1;

% get closest index
X = R.rThresh;
[a i] = min(abs(X-r));


% get data:
d = squeeze(R.itemReliability(i,:,:));
groupMode = 0;
if size(d,1)==1
    disp('group data')
    groupMode = 1;
end
if groupMode
    m = d;
else
    m = mean(d,2);
end
mm = mean(m);
[s si] = sort(m, 'descend');

   
% plot it:
figure('Color', [1 1 1], ...
    'Position', [ 97   659   418   350])
[n c] = hist(m, 10);
bar(c,n, 'FaceColor', [.8 .8 .8], 'EdgeColor', [.8 .8 .8])
set(gca, 'FontSize', 20)
xlim([0 1])
set(gca, 'Xtick', [0:.2:1]);
ylim([0 max(n)+2])
hold on
plot([mm mm], ylim, 'k', 'LineWidth', 2);
text(min(xlim), max(ylim), sprintf('  r=%2.2f', mm), ...
    'FontSize', 20, 'VerticalAlign', 'top', 'HorizontalAlign', 'left');
title('Item Pattern Reliability')
xlabel('Split-half pattern reliability')
ylabel('count of items')
% th = sprintf('ItemPatternsHist_voxelR>%2.2f.png', r);
th = sprintf('ItemPatternsHist_voxelR=%2.2f.png', r);
saveFigureHelper(saveFigFlag, saveDir, th);

