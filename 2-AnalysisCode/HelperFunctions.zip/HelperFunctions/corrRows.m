function C = corrRows(A, B, dim)

%If dim isn't specified default 1
if nargin == 2
    dim = 1;
end

C = corrColumns(A', B', dim);

C = C';
