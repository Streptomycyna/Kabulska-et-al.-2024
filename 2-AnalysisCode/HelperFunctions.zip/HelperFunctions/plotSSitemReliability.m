function plotSSitemReliability(X, itemReliability)

% plot it:
figure('Color', [ 1 1 1], 'Position', [  366   626   606   507])
plot(X,itemReliability, 'Color', [.5 .5 .5]);
hold on
plot(X, mean(itemReliability,2), 'k', 'LineWidth', 3);
set(gca, 'FontSize', 20)
axis('tight')
ylim([0 1]);
xlabel('Voxel-Reliability Threshold')
ylabel('Item Pattern Reliability')
title('Item by Voxel Reliability', 'FontSize', 24)
