function R = computeReliabilityGroup18(G, saveDir)

% Leyla Tarhan
% ltarhan@g.harvard.edu
% 12/2018
% MATLAB R2017b

% compute split-half reliability in group data and assess several possible 
% reliability-based voxel inclusion thresholds. No Brain Voyager 
% dependencies required. 

% inputs:
    % - G: GroupModel struct with paths to brainPatterns and gray matter
    % mask datafiles for the group data.
    % - saveDir: directory to save R struct in.
    
% output: 'R' struct:
%     R =
% 
%     struct with fields:
% 
%     itemReliability: [41�60 single]
%     rThresh: [1�41 double]
%     condNames: {60�1 cell}
%     name: 'Group (N=13)'
%     voxCount: [1�41 double]
%     voxTotal: 43949
%     allVoxelCorr: [106720�1 single]

% -------------------------------------------------------------------------
% compute reliabilities
fn = fullfile(saveDir, 'ReliabilitiesGroup.mat');
if ~exist(saveDir, 'dir'), mkdir(saveDir), end;


if ~exist(fn) % didn't already compute reliability
    
    % compute it
    [itemReliability, X, voxCount, N, condNames] = computeItemByVoxelReliability18(G.brainPatterns, G.cortexMask);
    
    % get voxelCorr for all voxels, for visualization purposes
    [voxelCorr] = getSplitHalfVoxelReliability18(G.brainPatterns);
    
    % bundle it for plotting
    R.itemReliability   = itemReliability;
    R.rThresh           = X;
    R.condNames         = condNames;
    R.name              = G.name;
    R.voxCount          = voxCount;
    R.voxTotal          = N;
    R.allVoxelCorr      = voxelCorr;
    
    
    save(fn, 'R');
else % already computed reliability
    load(fn);
    disp('group item reliability already computed');
end


