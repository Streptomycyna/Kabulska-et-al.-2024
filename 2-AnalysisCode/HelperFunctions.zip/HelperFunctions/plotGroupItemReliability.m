function plotGroupItemReliability(R, saveDir)

% vars needed
X = R.rThresh;
itemReliability = R.itemReliability;
voxCount = R.voxCount;

% plot it:
figure('Color', [ 1 1 1], 'Position', [205   706   972   392])
subplot(121)
plot(X,itemReliability, 'Color', [.5 .5 .5]);
hold on
plot(X, mean(itemReliability,2), 'k', 'LineWidth', 3);
set(gca, 'FontSize', 20)
axis('tight')
ylim([0 1]);
xlabel('Voxel-Reliability Threshold')
ylabel('Item Reliability')
% title('Sorted Voxel Reliability', 'FontSize', 24)
title(R.name, 'FontSize', 24);

subplot(122)
idx = find(X>=0.0 & voxCount>0);
barh(X(idx), voxCount(idx), 'FaceColor', [.5 .5 .5], 'EdgeColor', [1 1 1])

set(gca, 'FontSize', 20)
xlim([0 max(voxCount(idx))*1.25])
ylim([-.05, 1.05])
ylabel('Voxel-Reliability Threshold')
xlabel('Count of Voxels')
title('Voxel Count at Thresh', 'FontSize', 24)
for i=1:length(idx)
    text(voxCount(idx(i)), X(idx(i)), sprintf('  %d', voxCount(idx(i))), 'FontSize', 16);
end
set(gca, 'Xtick', []);

% save it
saveFigureHelper(1, saveDir, ['ItemByVoxelThresh_' R.name '.png']);
disp('saving figure!')
