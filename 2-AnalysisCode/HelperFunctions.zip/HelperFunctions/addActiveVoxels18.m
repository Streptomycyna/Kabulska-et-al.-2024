function ROI = addActiveVoxels18(S, ROI, tTHRESH)
% Leyla Tarhan
% ltarhan@g.harvard.edu
% 12/2018
% MATLAB R2017b

% save the indices of all active voxels in the gray matter. No Brain
% Voyager dependencies required.

% inputs:
    % - S: SubjectModel for a single subject or the group, with path to
    % cortex mask and t-map.
    % - ROI: ROI struct (previously initialized)
    % - tTHRESH: activity-based voxel inclusion threshold

% output: 'ROI' struct:
%     ROI =
% 
%     struct with fields:
% 
%     reliableGrayMatter: [10159�1 double]
%     rThresh: 0.3000
%     activeGrayMatter: [11890�1 double]

%--------------------------------------------------------------------------
%% load in data

% t-map
tm = load(S.tMap);
tMap = tm.tMap;

% gray matter mask
gm = load(S.cortexMask);
gmMask = gm.gmVec;

%% get active voxels in gray matter

fprintf('%s: adding active gray matter voxels...\n', S.name)

% threshold by activity:
activeMask = tMap > tTHRESH;
% make sure the thresholding worked:
assert(all(tMap(activeMask) > tTHRESH), 'WARNING: activity thresholding didn''t work as expected.');

% get active voxels within the gray matter:
activeGM = gmMask & activeMask;

%% update ROI struct

% save the indices for voxels that were reliable & in the gray matter
ROI.activeGrayMatter = find(activeGM);

end