function voxelCorr = get1FoldSplitHalfVoxelReliability(bpFileName, whichRuns)

% ltarhan@g.harvard.edu
% 12/2018
% MATLAB R2017b

% calculate split-half reliability for all voxels based on the functional
% data in brainPatterns. Only do this for the specified runs. No Brain Voyager dependencies.

% inputs:
    % - bpFileName: full path to brain patterns data
    % - whichRuns: 'odd' or 'even' (which runs should reliability be
    % calculated over?)

% outputs:
    % - voxelCorr: r-value for each voxel (correlation bt odd and even
    % runs)

% -------------------------------------------------------------------------

%% load in the functional data
keyboard

brainPatterns = load(bpFileName);
bp = brainPatterns.Betas;
cn = brainPatterns.ConditionNames;

% make sure condNames match
assert(all(strcmp(cn.Odd, cn.Even)), 'condnames even/odd don''t match.')

% gather interim outputs:
condNames = cn.Odd;
betasEvenFlat = bp.Even;
betasOddFlat = bp.Odd;

%% split-half reliability

voxelCorr = corrRows(betasEvenFlat, betasOddFlat);