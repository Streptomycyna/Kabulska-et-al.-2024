function ROI = addReliableVoxels18(S, ROI, rTHRESH, rDataDir, groupFlag)
% Leyla Tarhan
% ltarhan@g.harvard.edu
% 12/2018
% MATLAB R2017b

% save the indices of all reliable voxels in the gray matter. No Brain
% Voyager dependencies required.

% inputs:
    % - S: SubjectModel for a single subject or the group, with path to
    % cortex mask.
    % - ROI: ROI struct (previously initialized)
    % - rTHRESH: reliability-based voxel inclusion threshold
    % - rDataDir: directory with R struct (contains split-half reliability
    % for every voxel)
    % - groupFlag: 1 if group data, 0 if SS data

% output: 'ROI' struct:
%     ROI =
% 
%     struct with fields:
% 
%     reliableGrayMatter: [10159�1 double]

%--------------------------------------------------------------------------
%% load in data

% reliability
if groupFlag
    rels = load(fullfile(rDataDir, 'ReliabilitiesGroup.mat')); 
else
    rels = load(fullfile(rDataDir, 'Reliabilities.mat'));
end
R = rels.R;

% gray matter mask
gm = load(S.cortexMask);
gmMask = gm.gmVec;

%% get reliable voxels in gray matter

fprintf('%s: adding reliable gray matter voxels...\n', S.name)

% threshold by reliability:
if groupFlag
    reliableMask = R.allVoxelCorr >  rTHRESH;
    % make sure the thresholding worked:
    assert(all(R.allVoxelCorr(reliableMask) > rTHRESH), 'WARNING: reliability thresholding didn''t work as expected.');
else
    % find this sub:
    subIdx = find(strcmp(R.subList, S.name));
    rMap = R.allVoxelCorr(:, subIdx);
    reliableMask = rMap > rTHRESH;
    % make sure the thresholding worked:
    assert(all(rMap(reliableMask) > rTHRESH), 'WARNING: reliability thresholding didn''t work as expected.');    
end

% get reliable voxels within the gray matter:
reliableGM = gmMask & reliableMask;

%% update ROI struct

% save the indices for voxels that were reliable & in the gray matter
ROI.reliableGrayMatter = find(reliableGM);

end