function plotItemReliabilities(R, rThresh, saveDir)

% params
saveFigFlag = 1;
minVoxCount = 25;


voxCount = R.voxCount';
subList =R.subList;
m = squeeze(mean(R.itemReliability,2));
m(voxCount<minVoxCount)=NaN;
N = length(subList);
x = repmat(R.rThresh, [N 1])';
posIdx = (R.rThresh>=0);
cmap = jet(N);

figure('Color', [ 1 1 1], 'Position', [  366   626   606   507])

opt = 2;
if opt==1
    
    % option 1: whole brain, then positive side of sweep
    set(gcf,'DefaultAxesColorOrder',cmap);
    plot(x(posIdx,:), m(posIdx,:), 'LineWidth', 3)
    legend(subList, 'Location', 'EastOutside');
    hold on
    m(m==0)=NaN;
    for i=1:N
        plot(repmat(-0.1, [1 N]), m(1,i), '.', 'MarkerSize', 20, 'Color', cmap(i,:))
    end
    set(gca, 'FontSize', 20)
    axis('tight')
    ylim([0 1]);
    xlim([-.2 1])
    set(gca, 'Xtick', [0:.2:1])
    xlabel('Voxel-Reliability Threshold')
    ylabel('Item Pattern Reliability')
    title('Sorted Voxel Reliability', 'FontSize', 24)
    if ~isempty(rThresh)
        hold on
        plot([rThresh rThresh], ylim, 'k:', 'LineWidth', 2);
    end
    fn = 'ItemReliability.png';
elseif opt==2
    
    % option 2: whole sweep
    set(gcf,'DefaultAxesColorOrder',cmap);
    m(m==0)=NaN;
    plot(x, m, 'LineWidth', 3)
    legend(subList, 'Location', 'EastOutside');
    set(gca, 'FontSize', 20)
    axis('tight')
    ylim([0 1]);
    xlabel('Voxel-Reliability Threshold')
    ylabel('Item Pattern Reliability')
    title('Sorted Voxel Reliability', 'FontSize', 24)
    fn = 'ItemReliability_fullsweep.png';
else
    error('unexpected plot options')
end

if ~isempty(rThresh)
    hold on
    plot([rThresh rThresh], ylim, 'k:', 'LineWidth', 2);
    title(sprintf('R>%2.2f', rThresh), 'FontSize', 24);
end
saveFigureHelper(saveFigFlag, saveDir, ['ItemReliability.png']);
