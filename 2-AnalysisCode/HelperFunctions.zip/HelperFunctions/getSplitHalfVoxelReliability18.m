function [voxelCorr, condNames, betasEvenFlat, betasOddFlat] = getSplitHalfVoxelReliability18(bpFileName)

% ltarhan@g.harvard.edu
% 12/2018
% MATLAB R2017b

% calculate split-half reliability for all voxels based on the functional
% data in brainPatterns. No Brain Voyager dependencies.

% inputs:
    % - bpFileName: full path to brain patterns data

% outputs:
    % - voxelCorr: r-value for each voxel (correlation bt odd and even
    % runs)
    % - condNames: condition names
    % - betasEvenFlat: brainPatterns (betas) for every voxel in response to
    % every condition, from the even runs (voxels x conditions)
    % - betasOddFlat: brainPatterns (betas) for every voxel in response to
    % every condition, from the odd runs (voxels x conditions)

% -------------------------------------------------------------------------

%% load in the functional data

brainPatterns = load(bpFileName);
bp = brainPatterns.Betas;
cn = brainPatterns.ConditionNames;

% make sure condNames match
assert(all(strcmp(cn.Odd, cn.Even)), 'condnames even/odd don''t match.')

% gather interim outputs:
condNames = cn.Odd;
betasEvenFlat = bp.Even;
betasOddFlat = bp.Odd;

%% split-half reliability

voxelCorr = corrRows(betasEvenFlat, betasOddFlat);