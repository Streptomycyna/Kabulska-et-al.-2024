function plotItemByItemAtThresh(R, r, saveDir)

saveFigFlag=1;

% get closest index
X = R.rThresh;
[a i] = min(abs(X-r));

% get data:
d = squeeze(R.itemReliability(i,:,:));
groupMode = 0;
if size(d,1)==1
    disp('group data')
    groupMode = 1;
end
if groupMode
    m = d;
else
    m = mean(d,2);
    se = std(d,[],2)./sqrt(size(d,2));
end
[s si] = sort(m, 'descend');


% helper data:
labs = R.condNames;


% plot it:
figure('Color', [1 1 1], ...
    'Position', [97         602        1503         407])
% subplot(1,3,1:2)
set(gca, 'FontSize', 12)
bar(m(si), 'FaceColor', [.8 .8 .8], 'EdgeColor', [1 1 1]);
hold on
if ~groupMode
    h=errorbar(m(si), se(si), '.', 'MarkerSize', .01, 'Color', [.2 .2 .2]);
    %errorbar_tick(h, 0);
end
ylim([0 1])
xlim([0 length(labs)+1])
set(gca, 'Xtick', 1:length(labs))
set(gca, 'Xticklabel', labs(si))
xticklabel_rotate;
th = sprintf('ItemPatternR1_voxelR=%2.2f.png', r);
ylabel('split-half pattern reliability', 'FontSize', 20)
title(sprintf('Item Pattern Reliability (within Voxels R>%2.2f)', r), ...
    'FontSize', 24);
box('off')

th = sprintf('IndividualItemPatterns_voxelR=%2.2f.png', r);

saveFigureHelper(saveFigFlag, saveDir, th);

