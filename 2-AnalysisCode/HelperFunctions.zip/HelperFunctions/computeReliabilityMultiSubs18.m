function R = computeReliabilityMultiSubs18(SubjectModels, saveDir)
% Leyla Tarhan
% ltarhan@g.harvard.edu
% 12/2018
% MATLAB R2017b

% compute split-half reliability in SS data and assess several possible 
% reliability-based voxel inclusion thresholds. No Brain Voyager 
% dependencies required. 

% inputs:
    % - SubjectModels: struct with paths to brainPatterns and gray matter
    % mask datafiles for the group data.
    % - saveDir: directory to save R struct and SS figures to 

% output: 'R' struct:
%     R =
% 
%     struct with fields:
% 
%     itemReliability: [41�60 single]
%     rThresh: [1�41 double]
%     condNames: {60�1 cell}
%     name: 'Group (N=13)'
%     voxCount: [1�41 double]
%     voxTotal: 43949
%     allVoxelCorr: [106720�1 single]


% -------------------------------------------------------------------------
fn = fullfile(saveDir, 'Reliabilities.mat');
if exist(fn, 'file') % already computed SS reliabilities
    load(fn)
    disp('loading reliabilities')
else % compute it now
    ssSaveDir = fullfile(saveDir, 'SSFigs');
    if ~exist(ssSaveDir, 'dir'), mkdir(ssSaveDir), end;
    for s=1:length(SubjectModels)
        
        % get subject
        S = SubjectModels(s);
        disp(S.name);
        
        % compute reliabilities
        [itemReliability, X, voxCount, N, condNames] = computeItemByVoxelReliability18(S.brainPatterns, S.cortexMask);
         
        % plot single subject
        close(gcf)
        plotSSitemReliability(X, itemReliability);
        title(S.name);
        saveFigureHelper(1, ssSaveDir, [S.name '.png']);
        disp('saving figure!')
        
        % get voxelCorr for all voxels, for visualization purposes
        [voxelCorr] = getSplitHalfVoxelReliability18(S.brainPatterns);

        
        % save it
        R.allVoxelCorr(:, s) = voxelCorr;
        R.itemReliability(:,:,s) = itemReliability;
        R.rThresh = X;
        R.condNames = condNames;
        R.subList{s} = S.name;
        R.voxCount(s,:) = voxCount;
        R.voxTotal(s,:) = N;
        
    end
    % save it:
    close all
    save(fn, 'R');
    disp('saved!')
end