function [itemReliability, rRange, voxCount, N, condNames] = computeItemByVoxelReliability18(bpFileName, gmFileName)
% Leyla Tarhan
% ltarhan@g.harvard.edu
% 12/2018
% MATLAB R2017b

% calculate split-half reliability for each condition's response pattern at
% a range of possible inclusion thresholds (at each threshold, calculate
% reliability among the voxels that survive that threshold). No Brain
% Voyager dependencies. 

% inputs:
    % - bpFileName: full path to file with functional data (betas) for each
    % voxel
    % - gmFileName: full path to file with gray matter mask 

% outputs:
    % - itemReliability: reliability for each condition's pattern at the inclusion
    % thresholds listed in rRange (nThresholds x nConditions)
    % - rRange: possible inclusion thresholds (hard-coded here)
    % - voxCount: number of voxels that survive each inclusion threshold in
    % rRange
    % - N: # of gray-matter voxels included in the split-half reliability
    % map of the brain
    % - condNames: condition names

% -------------------------------------------------------------------------

% get split half reliability for each voxel
[voxelCorr, condNames, betasEven, betasOdd] = getSplitHalfVoxelReliability18(bpFileName);

% get voxel idx within mask:
if exist('gmFileName', 'var') && ~isempty(gmFileName) % saved gray matter mask
    gm = load(gmFileName);
    maskGM = gm.gmVec;
else % assume everything's in the gray matter
    maskGM = ones(size(voxelCorr));
end
voxelIdx = find(maskGM(:)~=0 & ~isnan(voxelCorr));
N = length(voxelIdx);

% crop data (only include gray matter voxels):
voxelCorrLong = voxelCorr;
voxelCorr = voxelCorr(voxelIdx);
betasEven = betasEven(voxelIdx,:);
betasOdd  = betasOdd(voxelIdx,:);

% get item reliability as a function of reliability:
disp('getting item reliabilities')
rRange = [-1:.05:1];
for i=1:length(rRange)
    
    % which voxels under consideration
    theseVox = voxelCorr>=rRange(i);
    
    % get item reliability in these voxels
    d1 = betasEven(theseVox,:);
    d2 = betasOdd(theseVox,:);
    itemReliability(i,:) = corrColumns(d1, d2);
    
    % voxel count
    voxCount(i)= sum(theseVox);
    
end

